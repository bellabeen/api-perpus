<?php
include_once(__DIR__."/../lib/peminjam.php");
include_once(__DIR__."/../lib/DataFormat.php");
header('Access-Control-Allow-Origin:*');
$peminjaman = new Peminjaman();
if(isset($_GET['id_peminjaman'])){
    $data=$peminjaman->getPeminjamanPilihan($_GET['id_peminjaman']);
} else {
    $data=$peminjaman->getPeminjaman();
}
$format=new DataFormat();


$view = isset($_GET['view']) ? $_GET['view']: null;

if($_GET['view']=='json') {
    echo $format->asJSON($data);
} else {
    echo $format->asTable($data["data"]);
}